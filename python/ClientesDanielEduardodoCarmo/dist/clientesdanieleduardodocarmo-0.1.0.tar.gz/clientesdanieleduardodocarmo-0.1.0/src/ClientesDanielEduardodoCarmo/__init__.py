from .clientes import Clientes, PaginaCompras

__all__ = ["Clientes", "PaginaCompras"]